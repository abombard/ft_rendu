# include "MonitorDisplay.hpp"

MonitorDisplay::MonitorDisplay(void)
{
	
}

MonitorDisplay::MonitorDisplay()
{
	
}

MonitorDisplay::MonitorDisplay( MonitorDisplay const &src )
{
	*this = src;
}

MonitorDisplay::~MonitorDisplay(void)
{
	
}

MonitorDisplay &	MonitorDisplay::operator=( MonitorDisplay const &rhs )
{
	if ( this != &rhs )
	{
		
	}
	return *this;
}

