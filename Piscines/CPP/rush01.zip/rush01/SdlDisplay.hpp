#ifndef SDLDISPLAY_HPP
# define SDLDISPLAY_HPP

# include <iostream>

class SdlDisplay {
	
	
private:
	
protected: 
	
};

std::ostream &	operator<<( std::ostream & o, SdlDisplay const & i );

# endif
