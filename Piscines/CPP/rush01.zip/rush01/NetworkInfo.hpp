#ifndef NETWORKINFO_HPP
# define NETWORKINFO_HPP

# include "AMonitorModule.hpp"
# include <sys/types.h>
# include <sys/sysctl.h>
# include <mach/vm_statistics.h>
# include <mach/mach_types.h>
# include <mach/mach_init.h>
# include <mach/mach_host.h>

template< typename S >
class NetworkInfo : public AMonitorModule<S> {
public:
	NetworkInfo( S & screen ) : AMonitorModule<S>(screen) {
		
			AMonitorModule<S>::setDisplay(screen, 20, 10, 0, 30);
	}
	
	NetworkInfo( NetworkInfo const &src ) : AMonitorModule<S>(src) { }
	
	virtual ~NetworkInfo(void) {
		if (this->_display)
			delete this->_display;
	}
	
	NetworkInfo &	operator=( NetworkInfo const &rhs ) {
		if ( this != &rhs ) {
			this->_info = rhs._info;
		}
		return *this;
	}

	virtual void		update( void ) {
		long long 	buf = 0;
		size_t 		size = sizeof(buf);

		this->_infos.clear();
		this->_infosName.clear();

		// ****** Network Info ****** //
		size = sizeof(buf);
		if ( sysctlbyname("", &buf, &size, NULL, 0) == 0 ) {
			this->_infosName.push_back("Bus Frequency: ");
			this->_infos.push_back(static_cast<long long>(buf));
		}
		this->_display->update(this->_infosName, this->_infos);
	}

private:
	NetworkInfo( void );
	std::list<long long>		_infos;
	std::list<std::string> 	_infosName;
	
protected: 
	
};

# endif
