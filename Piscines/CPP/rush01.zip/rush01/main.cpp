# include <iostream>
# include <unistd.h>
# include "SdlWin.hpp"
# include "NcWin.hpp"
# include "UserInfo.hpp"
# include "OSInfo.hpp"
# include "TimeInfo.hpp"
# include "CpuInfo.hpp"
# include "RamInfo.hpp"

template < typename T >
void	loop(T & screen) {
	UserInfo<T> userInfo(screen);
	OSInfo<T>	osInfo(screen);
	TimeInfo<T>	timeInfo(screen);
	CpuInfo<T>	cpuInfo(screen);
	RamInfo<T>	ramInfo(screen);

	while (1) {
		screen.clear();
		userInfo.update();
		osInfo.update();
		timeInfo.update();
		cpuInfo.update();
		ramInfo.update();
		screen.flip();
		if (screen.event() == -1)
			break ;
		usleep(170000);
	}
}

int main(int ac, char **av) {
	if (ac == 2) {
		std::string s(av[1]);

		if ( s.compare("ncurses") == 0 ) {
			NcWin win(800, 600);
			loop(win);
		}
		
	}
	else {
		try {
		SdlWin window(800, 600);
		loop(window);
		}
		catch (std::exception &e) {

			std::cout << e.what() << std::endl;
		}
	}
	return (0);
}
