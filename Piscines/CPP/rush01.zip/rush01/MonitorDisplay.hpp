#ifndef MONITORDISPLAY_HPP
# define MONITORDISPLAY_HPP

# include <iostream>

class MonitorDisplay {

	
protected: 
	
};

std::ostream &	operator<<( std::ostream & o, MonitorDisplay const & i );

# endif
