#ifndef DISPLAY_HPP
# define DISPLAY_HPP

#include <iostream>
#include <list>
#include <string>

class Display { // A DECLARER DANS UN FICHIER SEPARAY
protected:
	int			_width;
	int			_height;
	int			_x;
	int			_y;
private:
	Display(void);
	Display( Display const &src );
	Display &	operator=( Display const & rhs );
	
public:
	Display( int width, int height, int x, int y ) : _width(width), _height(height), _x(x), _y(y) {
		
	}
	virtual void	update(std::list<int> const & info) = 0;
	virtual void	update(std::list<long long> const & info) = 0;
	virtual void	update(std::list<std::string> const & infoName, std::list<long long> const & info) = 0;
	virtual void	update(std::list<std::string> const & info) = 0;
	virtual ~Display(void) {}
};

class SdlDisplay : public Display {
private:
	SdlWin &	_screen;
	SdlDisplay(void);
	SdlDisplay( SdlDisplay const &src );
	SdlDisplay &	operator=( SdlDisplay const & rhs );
	
public:
	SdlDisplay( SdlWin & screen, int width, int height, int x, int y ) : Display(width , height, x * 10, y * 20), _screen(screen) {}
	virtual void	update(std::list<int> const & info) {
		(void)info;
	}
	virtual void	update(std::list<long long> const & info) {
		(void)info;
	}
	virtual void	update(std::list<std::string> const & infoName, std::list<long long> const & info) {
		int y = this->_y + 1;
		std::list<std::string>::const_iterator itn = infoName.begin();
		for (std::list<long long>::const_iterator it = info.begin(); it != info.end(); ++it, ++itn) {
			this->_screen.ft_write_on_screen(*itn, 22, this->_x + 10, y, 0xFFFFFF);
			y+=22;
			if (*it) {
				this->_screen.ft_write_on_screen(std::to_string(*it), 22, this->_x + 20, y, 0xFFFFFF);
				y+=22;
			}
		}
	}
	virtual void	update(std::list<std::string> const & info) {
		int y = this->_y + 1;
		for (std::list<std::string>::const_iterator it = info.begin(); it != info.end(); ++it) {
			this->_screen.ft_write_on_screen(*it, 22, this->_x + 10, y, 0xFFFFFF);
			y += 22;
		}

	}
	virtual ~SdlDisplay(void) {}
};

class NcursesDisplay : public Display{
	private:
		NcWin &		_screen;
		NcursesDisplay(void);
		NcursesDisplay( NcursesDisplay const &src );
		NcursesDisplay &	operator=( NcursesDisplay const & rhs );

	public:
		NcursesDisplay( NcWin & screen, int width, int height, int x, int y ) : Display(width, height, x, y), _screen(screen) {}
		virtual void	update(std::list<int> const & info) {
			_screen.drawBorder(this->_x, this->_y, this->_width, this->_height);
			int x = 1;
			for (std::list<int>::const_iterator it = info.begin(); it != info.end(); ++it) {
				this->_screen.draw(std::to_string(*it), 1, x);
				x += 1;
			}
		}
		virtual void	update(std::list<std::string> const & infoName, std::list<long long> const & info) {
			_screen.drawBorder(this->_x, this->_y, this->_width, this->_height);
			int y = this->_y + 1;
			std::list<std::string>::const_iterator itn = infoName.begin();
			for (std::list<long long>::const_iterator it = info.begin(); it != info.end(); ++it, ++itn) {
				this->_screen.draw(*itn, this->_x + 1, y++);
				if (*it)
					this->_screen.draw(std::to_string(*it), this->_x + 1, y++);
			}
		}
		virtual void	update(std::list<long long> const & info) {
			_screen.drawBorder(this->_x, this->_y, this->_width, this->_height);
			int y = this->_y + 1;
			for (std::list<long long>::const_iterator it = info.begin(); it != info.end(); ++it) {
				this->_screen.draw(std::to_string(*it), this->_x + 1, y);
				y += 1;
			}
		}
		virtual void	update(std::list<std::string> const & info) {
			_screen.drawBorder(this->_x, this->_y, this->_width, this->_height);
			int y = this->_y + 1;
			for (std::list<std::string>::const_iterator it = info.begin(); it != info.end(); ++it) {
				this->_screen.draw(*it, this->_x + 1, y);
				y += 1;
			}
		}
		virtual ~NcursesDisplay(void) {}

};

#endif
